import 'package:mysql_client/mysql_client.dart';
import '../db/db.dart';

class MZService {
  /// 新增/更新患者，并返回 patient_id（用 name+phone 唯一）
  static Future<int> upsertPatientGetId({
    required String name,
    required String phone,
    String gender = '未知',
    String address = '',
  }) async {
    await Db.execute(
      'INSERT INTO huanzhe (name, phone, gender, address) '
      'VALUES (:name,:phone,:gender,:address) '
      'ON DUPLICATE KEY UPDATE '
      ' id=LAST_INSERT_ID(id), '
      ' name=VALUES(name), gender=VALUES(gender), address=VALUES(address)',
      {
        'name': name.trim(),
        'phone': phone.trim(),
        'gender': gender,
        'address': address.trim(),
      },
    );
    final r = await Db.query('SELECT LAST_INSERT_ID() AS patient_id');
    final idStr = r.rows.first.colByName('patient_id')?.toString() ?? '0';
    return int.parse(idStr);
  }

  /// 加入“就诊中”（若已在，就刷新活跃时间）
  static Future<void> enterSession(int patientId) async {
    await Db.execute(
      'INSERT INTO jiuzhen_session (patient_id) VALUES (:pid) '
      'ON DUPLICATE KEY UPDATE updated_at=NOW()',
      {'pid': patientId},
    );
  }

  /// 保存病历，返回 visit_id；顺手生成一个 8 位就诊号
  static Future<int> createVisit({
    required int patientId,
    String zhusu = '',
    String xianbingshi = '',
    String linchuangDx = '',
    String zhongyiDx = '',
    String remark = '',
  }) async {
    await Db.execute(
      'INSERT INTO jiuzhen (patient_id, zhusu, xianbingshi, linchuang_dx, zhongyi_dx, remark) '
      'VALUES (:pid,:zs,:xbs,:lcdx,:zydx,:rmk)',
      {
        'pid': patientId,
        'zs': zhusu,
        'xbs': xianbingshi,
        'lcdx': linchuangDx,
        'zydx': zhongyiDx,
        'rmk': remark,
      },
    );
    final v = await Db.query('SELECT LAST_INSERT_ID() AS visit_id');
    final visitId = int.parse(v.rows.first.colByName('visit_id')!.toString());
    await Db.execute(
      'UPDATE jiuzhen SET visit_no=LPAD(:vid,8,"0") WHERE id=:vid',
      {'vid': visitId},
    );
    return visitId;
  }

  /// 完成接诊：从“就诊中”移除
  static Future<void> finishSession(int patientId) async {
    await Db.execute('DELETE FROM jiuzhen_session WHERE patient_id=:pid', {
      'pid': patientId,
    });
  }

  /// 一步完成：保存病历 + 完成接诊（事务）
  static Future<int> saveVisitAndFinish({
    required int patientId,
    String zhusu = '',
    String xianbingshi = '',
    String linchuangDx = '',
    String zhongyiDx = '',
    String remark = '',
  }) async {
    await Db.execute('START TRANSACTION');
    try {
      final vid = await createVisit(
        patientId: patientId,
        zhusu: zhusu,
        xianbingshi: xianbingshi,
        linchuangDx: linchuangDx,
        zhongyiDx: zhongyiDx,
        remark: remark,
      );
      await finishSession(patientId);
      await Db.execute('COMMIT');
      return vid;
    } catch (e) {
      await Db.execute('ROLLBACK');
      rethrow;
    }
  }
}
